function on_step()
    Scene:get_host():set_camera_position(self:get_position());
end;

function on_update()
    Scene:get_host():set_camera_position(self:get_position());
end;
